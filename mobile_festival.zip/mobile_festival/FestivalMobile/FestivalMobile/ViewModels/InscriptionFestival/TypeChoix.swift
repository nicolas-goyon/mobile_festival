//
//  TypeChoix.swift
//  FestivalMobile
//
//  Created by etud on 22/03/2024.
//

import Foundation

enum TypeChoix{
    case Poste
    case Animation
    case SansChoix
}
