//
//  Tests.swift
//  FestivalMobile
//
//  Created by etud on 26/03/2024.
//

import Foundation
import SwiftUI

struct Tests: View{
    var body: some View{
        
        
        
        return List {
            VStack{
                Text("Test de la récupération des festivals")
            }
        }
    }
}
